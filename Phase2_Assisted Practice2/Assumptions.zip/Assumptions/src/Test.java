import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assumptions.assumeTrue;

class ExampleTest {

    @ParameterizedTest
    @ValueSource(ints = {1, 2, 3, -1})
    void test(int i) {
        assumeTrue(i >= 1, "Wrong Input, Only positive ints please");

        try {
            Thread.sleep(i);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}




























