import org.junit.jupiter.api.Test;



@Fast

public class FastTest {



    @Test

    @Fast

    public void yourTestMethod() {

        System.out.println("This is a fast test method.");

    }



    @Test

    public void anotherTestMethod() {

        System.out.println("This is another test method.");

    }

}