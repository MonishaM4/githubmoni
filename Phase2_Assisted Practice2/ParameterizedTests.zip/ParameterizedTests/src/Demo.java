import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class Demo {

    @ParameterizedTest
    @ValueSource(ints = {4, 5, 6})
    void testValueSource(int i) {
        System.out.println(i);
    }

    @ParameterizedTest
    @ValueSource(strings = {"4", "5", "6"})
    void testValueSourceString(String s) {
        assertTrue(Integer.parseInt(s) < 5);
    }
}
