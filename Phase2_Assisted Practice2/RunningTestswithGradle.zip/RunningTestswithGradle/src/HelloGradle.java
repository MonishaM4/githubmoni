public class HelloGradle {
    public static void main(String[] args) {
        System.out.println("Hello, welcome to Gradle project!!");
    }
}
