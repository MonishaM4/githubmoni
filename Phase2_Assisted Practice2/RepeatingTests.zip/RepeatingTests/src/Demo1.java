import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.RepetitionInfo;

public class Demo1 {
@RepeatedTest (5)

	void test_with_RepetitionInfo_Injection(RepetitionInfo repetitionInfo) {

	System.out.println("Number of excecution");
	assertEquals(5, repetitionInfo.getTotalRepetitions());

	System.out.println("Current rest Count = "+repetitionInfo.getCurrentRepetition());

}
}
