import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class DynamicTests1 {

    @TestFactory
    Stream<DynamicTest> dynamicTestsEx() {
        List<Integer> inputList1 = Arrays.asList(1, 2, 3);
        List<Integer> inputList2 = Arrays.asList(10, 20, 30);

        List<DynamicTest> dynamicTests = new ArrayList<>();

        for (int i = 0; i < inputList1.size(); i++) {
            int input1 = inputList1.get(i);
            int input2 = inputList2.get(i);

            String testName = "Test Addition " + input1 + " + " + input2;
            DynamicTest dynamicTest = DynamicTest.dynamicTest(testName, () -> {
                int result = MyUtils.add(input1, input2);
                // Your assertions here
                // For example:
                // assertEquals(expectedResult, result);
            });

            dynamicTests.add(dynamicTest);
        }

        return dynamicTests.stream();
    }

    static class MyUtils {
        static int add(int x, int y) {
            return x + y;
        }
    }
}
