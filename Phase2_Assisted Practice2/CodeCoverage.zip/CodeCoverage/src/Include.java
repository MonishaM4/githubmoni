import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.IncludeTags;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
@SelectPackages("com.howtodoinjava.junit5.examples")
@IncludeTags("production")
public class Include {

    @Test
    @Tag("development")
    @Tag("production")
    void testCaseA(TestInfo testInfo) {
        // Run in all environments
    }

    @Test
    @Tag("development")
    void testCaseB(TestInfo testInfo) {
        // Run in development environment
    }

    @Test
    @Tag("development")
    void testCaseC(TestInfo testInfo) {
        // Run in development environment
    }
}
