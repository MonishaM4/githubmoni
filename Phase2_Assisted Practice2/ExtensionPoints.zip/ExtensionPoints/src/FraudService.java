public class FraudService {
    private String serviceName;

    public FraudService(String serviceName) {
        this.serviceName = serviceName;
    }

    public FraudService() {
		// TODO Auto-generated constructor stub
	}

	public String getServiceName() {
        return serviceName;
    }
}
