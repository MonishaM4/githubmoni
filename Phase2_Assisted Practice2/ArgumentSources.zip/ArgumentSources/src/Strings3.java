import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.extension.ExtensionContext;

import org.junit.jupiter.params.ParameterizedTest;

import org.junit.jupiter.params.provider.Arguments;

import org.junit.jupiter.params.provider.ArgumentsProvider;

import org.junit.jupiter.params.provider.ArgumentsSource;



import java.util.stream.Stream;



public class Strings3 {



    @ParameterizedTest

    @ArgumentsSource(MyArgumentsProvider.class)

    void testWithArgumentsSource(String argument) {

        assertNotNull(argument);

        // You can add more assertions or logic if needed

    }



    // Custom ArgumentsProvider

    static class MyArgumentsProvider implements ArgumentsProvider {

        @Override

        public Stream<? extends Arguments> provideArguments(ExtensionContext context) {

            return Stream.of("apple", "banana").map(Arguments::of);

        }

    }



    // Your other parameterized tests using different providers

    // Add other tests as needed...

}

