

	public class MagicBuilder {

	    public static int getLucky() {
	        return 7;
	    }
	}



