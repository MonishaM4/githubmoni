import static org.junit.Assert.assertEquals;



import org.junit.Ignore;

import org.junit.Test;



public class JunitDemoExample {



    public String message = "Welcome";



    JUnitMessage junitMsg = new JUnitMessage(message);



    @Ignore

    @Test

    public void testJUnitMessage() {

        System.out.println("Junit Message is printing ");

        assertEquals(message, junitMsg.printMessage());

    }



    @Test

    public void testJUnitHiMessage() {

        message = "Hi! " + message;

        System.out.println("Junit Hi Message is printing ");

        assertEquals(message, junitMsg.printHiMessage());

    }

}



class JUnitMessage {

    private String message;



    public JUnitMessage(String message) {

        this.message = message;

    }



    public String printMessage() {

        return message;

    }



    public String printHiMessage() {

        return "Hi! " + message;

    }

}
