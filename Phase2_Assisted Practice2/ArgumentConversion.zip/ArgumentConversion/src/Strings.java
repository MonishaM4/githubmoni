import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.junit.jupiter.api.Assertions.assertNotNull;



import java.util.concurrent.TimeUnit;



import org.junit.jupiter.params.ParameterizedTest;

import org.junit.jupiter.params.provider.EnumSource;

import org.junit.jupiter.params.provider.ValueSource;



public class Strings {



    @ParameterizedTest

    @ValueSource(strings = "SECONDS")

    void testWithImplicitArgumentConversion(TimeUnit argument) {

        assertNotNull(argument);

        assertEquals("SECONDS", argument.name());

        // You can add more assertions or logic if needed

    }



    // Example with EnumSource

    @ParameterizedTest

    @EnumSource(TimeUnit.class)

    void testWithEnumSource(TimeUnit argument) {


        assertNotNull(argument);

        // You can add more assertions or logic if needed

    }

}

