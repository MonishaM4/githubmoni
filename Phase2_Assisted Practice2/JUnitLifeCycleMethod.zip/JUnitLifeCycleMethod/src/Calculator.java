
public class Calculator {
	
 
	    public static int add(int a, int b) { 
	        return a + b;
	    }
	}

