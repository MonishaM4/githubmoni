/**
 * 
 */
/**
 * 
 */
module AreaforDifferentGeometric {
}