import java.io.IOException;

import java.io.PrintWriter;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;

import jakarta.servlet.http.HttpServletRequest;

import jakarta.servlet.http.HttpServletResponse;



/**

 * Servlet implementation class ProductServlet

 */

public class ProductServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

       

    /**

     * @see HttpServlet#HttpServlet()

     */

    public ProductServlet() {

        super();

        // TODO Auto-generated constructor stub

    }



	/**

	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)

	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// TODO Auto-generated method stub

		response.getWriter().append("Served at: ").append(request.getContextPath());

		response.setContentType("text/html");

        PrintWriter out = response.getWriter();



        // Retrieve the product ID from the request parameters

        int productId = Integer.parseInt(request.getParameter("productId"));



        Connection connection = null;



        try {

            // Load the JDBC driver

        	Class.forName("com.mysql.cj.jdbc.Driver");



            // Establish a connection

            String jdbcUrl = "jdbc:mysql://localhost:3306/ecommerce";

            String username = "root";

            String password = "root";



            connection = DriverManager.getConnection(jdbcUrl, username, password);



            // Prepare and execute the SQL query

            String sql = "SELECT * FROM products WHERE product_id=?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

                preparedStatement.setInt(1, productId);



                ResultSet resultSet = preparedStatement.executeQuery();



                // Check if the product is found

                if (resultSet.next()) {

                    out.println("<h2>Product Details:</h2>");

                    out.println("Product ID: " + resultSet.getInt("product_id") + "<br>");

                    out.println("Product Name: " + resultSet.getString("product_name") + "<br>");

                    out.println("Product Price: $" + resultSet.getDouble("product_price") + "<br>");

                    out.println("Product Description: " + resultSet.getString("product_description") + "<br>");

                } else {

                    out.println("<h2>Error:</h2>");

                    out.println("Product not found with ID: " + productId);

                }

            }

        } catch (ClassNotFoundException e) {

            e.printStackTrace();

            out.println("<h2>Error:</h2>");

            out.println("MySQL Connector/J not found. Make sure the JAR file is in the lib directory.");

        } catch (SQLException e) {

            e.printStackTrace();

            out.println("<h2>Error:</h2>");

            out.println("An error occurred while processing the request.");

        } finally {

            // Close the connection in the finally block

            try {

                if (connection != null && !connection.isClosed()) {

                    connection.close();

                }

            } catch (SQLException e) {

                e.printStackTrace();

            }

        }}

	/**

	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)

	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// TODO Auto-generated method stub

		doGet(request, response);

	}



}

