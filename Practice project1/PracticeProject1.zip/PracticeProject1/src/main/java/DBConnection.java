
import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.SQLException;



public class DBConnection {



    public static void main(String[] args) {

        Connection connection = null;



        try {

            // Load the JDBC driver

            Class.forName("com.mysql.cj.jdbc.Driver");



            // Establish a connection

            String jdbcUrl = "jdbc:mysql://localhost:3306/ecommerce";

            String username = "root";

            String password = "root";



            connection = DriverManager.getConnection(jdbcUrl, username, password);



            if (connection != null) {

                System.out.println("Connected to the database!");

            } else {

                System.out.println("Failed to connect to the database.");

            }



        } catch (ClassNotFoundException | SQLException e) {

            e.printStackTrace();

        } finally {

            // Close the connection in the finally block

            try {

                if (connection != null && !connection.isClosed()) {

                    connection.close();

                }

            } catch (SQLException e) {

                e.printStackTrace();

            }

        }

    }

}