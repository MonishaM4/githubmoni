package AccessSpecifier_package;

public class accessSpecifiers1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	


System.out.println("Dafault Access Specifier");
defAccessSpecifier obj = new defAccessSpecifier(); 		  
obj.display(); 

}
}
