/**
 * 
 */
/**
 * 
 */
module ClassObj_constructor {
}