package ClassObj_constructorpac;

public class MyClass {
	
	    // Fields or variables
	    private String message;

	    // Constructor
	    public MyClass(String initialMessage) {
	        this.message = initialMessage;
	    }

	    // Method to get the message
	    public String getMessage() {
	        return message;
	    }

	    public static void main(String[] args) {
	        // Creating an object of MyClass
	        MyClass myObject = new MyClass("Hello, Constructor!");

	        // Getting and printing the message
	        System.out.println(myObject.getMessage());
	    }
	}


